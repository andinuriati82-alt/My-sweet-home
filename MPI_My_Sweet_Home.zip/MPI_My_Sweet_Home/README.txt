MPI MY SWEET HOME — PANDUAN PENGGUNAAN

Isi paket:
- index.html: Media Pembelajaran Interaktif yang berjalan di browser.

Cara membuka secara offline:
1. Ekstrak file ZIP.
2. Buka folder MPI_My_Sweet_Home.
3. Klik dua kali index.html atau buka dengan Chrome/Edge.
4. Tidak memerlukan instalasi atau koneksi internet.

Cara memublikasikan sebagai MPI online:
1. Ekstrak ZIP.
2. Unggah index.html ke layanan hosting statis yang mendukung HTML (misalnya GitHub Pages, Netlify, atau hosting sekolah).
3. Ikuti instruksi layanan hosting untuk mendapatkan tautan publik.

Catatan:
- Paket ini mandiri dan tidak menggunakan pustaka eksternal.
- Skor pilihan ganda dan simulasi dihitung di halaman.
- Jawaban refleksi tidak dikirim ke guru/server; halaman ini tidak menyimpan data setelah ditutup.
- Guru dapat menyesuaikan teks, soal, dan identitas sekolah dengan mengedit index.html menggunakan editor teks.
